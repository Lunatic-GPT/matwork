function gems_csrecon(fid_prefix,method,ref,ref_ind,recon_ind)
%gems_csrecon(fid_prefix,method[,ref,ref_ind,recon_ind])

tic;
np=readPar(fid_prefix,'np');
nv=readPar(fid_prefix,'nv');
ns=readPar(fid_prefix,'ns');
npecs=readPar(fid_prefix,'npecs');
m2=mask_cs1d(fid_prefix);

pro=readPar(fid_prefix,'pro');
ppe=readPar(fid_prefix,'ppe');
lro=readPar(fid_prefix,'lro');
lpe=readPar(fid_prefix,'lpe');
%figure;imagesc(m2);drawnow;
arraydim=readPar(fid_prefix,'arraydim');
ne=arraydim;

z=read_fid([fid_prefix,'.fid']);

z=reshape(z,[np/2,ns,npecs,ne]);

z2=zeros(np/2,nv,ns,ne);
                                                                                                                                                                                               
for i=1:ns
    for j=1:ne  
     z2(:,m2(:,i,j)>0,i,j)=z(:,i,:,j);
    end
end
z2=fov_shift_kspace(z2,[0,-ppe],[lro,lpe]);
m2=shiftdim(m2,-1);
m2=repmat(m2,[np/2,1,1,1]);
orient = readPar(fid_prefix,'orient');
orient=orient(2:end-1);
switch method
    case 'ktf'
      %  z2=z2.*m2;
        recon=zeros(size(z2));
        
        for i=1:size(z2,3)            
          fprintf('Slice %d\n',i);
          tmp=z2(:,:,i,:);
          tmp=permute(tmp,[2,1,3,4]);
          tmp=circshift(tmp,[size(tmp,1)/2,size(tmp,2)/2,0,0]);
          tmp=squeeze(tmp);
          recon(:,:,i,:)=cart_ktFOCUSS_KTFOCUSS(tmp);        
        end
        
        %{
        tmp=permute(z2,[2,1,3,4]);
        tmp=circshift(tmp,[size(tmp,1)/2,size(tmp,2)/2,0,0]);
        recon=cart_ktFOCUSS_KTFOCUSS(tmp.*m2);
        %}
 
        recon=circshift(recon,[size(z2,1)/2,size(z2,2)/2,0,0]);
        recon=permute(recon,[2,1,3,4]);
      


    case 'ft'
        
         recon=run_cs_FTt(z2,m2,false,1:9,'ft');    %perform FT along the time dimension as the sparsifying transform.


    case 'klt'
        recon=run_cs_FTt(z2,m2,false,1:9,'klt');    %perform KLT along the time dimension as the sparsifying transform.
        

      otherwise 
          error('unknow methods\n');
end

    


writesdt4(abs(recon),[fid_prefix,'_',method]);
writesdt4(angle(recon),[fid_prefix,'_',method,'_ph']);

    fprintf('gems_csrecon finished in %4.1f s\n',toc);
    

function im_res=run_cs_FTt(z,mask,nodisplay,isl,xfm)


z=z/max(abs(z(:)));
data=z.*mask;
%data=data/max(abs(data(:)));
N = size(data); 	% image Size
TVWeight = 0; 	% Weight for TV penalty
xfmWeight = 0.01;	% Weight for Transform L1 penalty
Itnlim = 8;		% Number of iterations

%generate Fourier sampling operator
FT = p2DFTxp(mask, N, 1, 2);

% scale data

%data = data/max(abs(im_dc(:)));
%im_dc = im_dc/max(abs(im_dc(:)));

%generate transform operator
%XFM = Wavelet_rect('Daubechies',4,4);	% Wavelet
%sz=size(data);
%XFM=Wavelet_ISU(sz(1:2));
% initialize Parameters for reconstruction
param = init;
param.FT = FT;
param.TV = TVOPxp;
param.data = data;
param.TVWeight =TVWeight;     % TV penalty 
param.xfmWeight = xfmWeight;  % L1 wavelet penalty
param.Itnlim = Itnlim;


in=sum(data,4);
nm=sum(mask,4);
nm(nm==0)=1;
in=in./nm;
im_dc=ifft2c(repmat(in,[1,1,1,size(data,4)]));

if strmatch(xfm,'ft')
XFM=FTt;
elseif strmatch(xfm,'klt')
 m2=(nm==size(mask,4));
 d3=zeros(length(find(m2>0)),size(mask,4));
for i=1:size(mask,4)
    tmp=data(:,:,:,i);
    d3(:,i)=tmp(m2);
end
 XFM=KLT(d3);
end
param.XFM=XFM;

if ~nodisplay
  figure(100);
  for i=1:length(isl)
    subplot(1,length(isl),i); imshow(abs(im_dc(:,:,isl(i))),[]); 
    drawnow;   
  end
      
 end

res = XFM*im_dc;
% do iterations
for n=1:1
	res = fnlCg_xp(res,param);
	im_res = XFM'*res;
    if n==40
        ph=angle(im_res);
        param.FT=p2DFTxp(mask,N,cos(ph)+1i*sin(ph));
        im_res=im_res.*(cos(ph)-1i*sin(ph));
        res=XFM*im_res;
    end
    
    if ~nodisplay
	  figure(100);
      for i=1:length(isl)
         subplot(1,length(isl),i); imshow(abs(im_res(:,:,isl(i))),[]);
         drawnow;   
      end
      %subplot(1,2,2);imshow(angle(im_res(:,:,isl)),[]); drawnow;
    end
end

