function res = mtimes(a,b)

    res=zeros(size(b));
    for i=1:size(b,1)
        for j=1:size(b,2)
            for k=1:size(b,3)
                if a.adjoint
                   res(i,j,k,:) = a.m'*squeeze(b(i,j,k,:));
                else
                   res(i,j,k,:) = a.m*squeeze(b(i,j,k,:));
                end
            end
        end
    end





    
