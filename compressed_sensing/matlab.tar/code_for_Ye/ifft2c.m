function res = ifft2c(x)
%
%
% res = ifft2c(x)
% 
% orthonormal centered 2D ifft
%
% (c) Michael Lustig 2005

x=circshift(x,[size(x,1)/2,size(x,2)/2,0,0]);
n=size(x,1)*size(x,2);
res = sqrt(n)*ifft(ifft(x,[],1),[],2);

res=circshift(res,[size(x,1)/2,size(x,2)/2,0,0]);


