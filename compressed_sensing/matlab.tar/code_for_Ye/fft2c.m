function res = fft2c(x)

% res = fft2c(x)
% 
% orthonormal forward 2D FFT
%
% (c) Michael Lustig 2005



x=circshift(x,[size(x,1)/2,size(x,2)/2,0,0]);
n=size(x,1)*size(x,2);
res = 1/sqrt(n)*fft(fft(x,[],1),[],2);

res=circshift(res,[size(x,1)/2,size(x,2)/2,0,0]);


