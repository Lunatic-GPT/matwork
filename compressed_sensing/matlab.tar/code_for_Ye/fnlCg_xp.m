function x = fnlCg_xp(x0,params)
%-----------------------------------------------------------------------
%
% res = fnlCg(x0,params)
%
% implementation of a L1 penalized non linear conjugate gradient reconstruction
%
% The function solves the following problem:
%
% given k-space measurments y, and a fourier operator F the function 
% finds the image x that minimizes:
%
% Phi(x) = ||F* W' *x - y||^2 + lambda1*|x|_1 + lambda2*TV(W'*x) 
%
%
% the optimization method used is non linear conjugate gradient with fast&cheap backtracking
% line-search.
% 
% (c) Michael Lustig 2007
%-------------------------------------------------------------------------
x = x0;


% line search parameters
maxlsiter = params.lineSearchItnlim ;
gradToll = params.gradToll ;
alpha = params.lineSearchAlpha; 
beta = params.lineSearchBeta;
t0 = params.lineSearchT0;
k = 0;

% copmute g0  = grad(Phi(x))

g0 = wGradient(x,params);

dx = -g0;

% iterations
while(1)
tic;
% backtracking line-search

	% pre-calculate values, such that it would be cheap to compute the objective
	% many times for efficient line-search
    [FTXFMtx, FTXFMtdx, DXFMtx, DXFMtdx,DTFMtx,DTFMtdx,XFMtx,XFMtdx] = preobjective(x, dx, params);
    [f0,ERRobj,RMSerr,TV,TVt,XFM,obj2] = objective(FTXFMtx, FTXFMtdx, DXFMtx, DXFMtdx,DTFMtx,DTFMtdx,XFMtx,XFMtdx,x,dx, 0, params);
  
    if k==0
      disp(sprintf('-: obj(total) %f, obj (data): %f, RMS: %f, TV: %f, TVt: %f, XFM: %f, obj2: %f', f0,ERRobj,RMSerr,TV/params.TVWeight,TVt,XFM/params.xfmWeight,obj2));
    end
    
	t = t0;
        [f1, ERRobj, RMSerr,TV,TVt,XFM,obj2]  =  objective(FTXFMtx,FTXFMtdx,DXFMtx,DXFMtdx,DTFMtx,DTFMtdx,XFMtx,XFMtdx,x,dx, t, params);
	
	lsiter = 0;

	while (f1 > f0 - alpha*t*abs(g0(:)'*dx(:))) && (lsiter<maxlsiter)
		lsiter = lsiter + 1;
		t = t * beta;
		[f1, ERRobj, RMSerr,TV,TVt,XFM,obj2]  =  objective(FTXFMtx, FTXFMtdx, DXFMtx, DXFMtdx,DTFMtx,DTFMtdx,XFMtx,XFMtdx,x,dx, t, params);
	end

	if lsiter == maxlsiter
		disp('Reached max line search,.... not so good... might have a bug in operators. exiting... ');
		return;
	end

	% control the number of line searches by adapting the initial step search
	if lsiter > 2
		t0 = t0 * beta;
	end 
	
	if lsiter<1
		t0 = t0 / beta;
	end

	x = (x + t*dx);

	%--------- uncomment for debug purposes ------------------------	
	disp(sprintf('%4.1f: obj(total) %f, obj (data): %f, RMS: %f, TV: %f, TVt: %f, XFM: %f, obj2: %f',toc,f1,ERRobj,RMSerr,TV/params.TVWeight,TVt,XFM/params.xfmWeight,obj2));

	%---------------------------------------------------------------
	
    %conjugate gradient calculation
    
	g1 = wGradient(x,params);
	bk = g1(:)'*g1(:)/(g0(:)'*g0(:)+eps);
	g0 = g1;
	dx =  - g1 + bk* dx;
	k = k + 1;
	
	%TODO: need to "think" of a "better" stopping criteria ;-)
	if (k > params.Itnlim) | (norm(dx(:)) < gradToll) 
		break;
	end
end


return;


function [FTXFMtx, FTXFMtdx, DXFMtx, DXFMtdx,DTFMtx,DTFMtdx,XFMtx,XFMtdx] = preobjective(x, dx, params)

% precalculates transforms to make line search cheap

XFMtx=params.XFM'*x;
XFMtdx=params.XFM'*dx;
FTXFMtx = params.FT*XFMtx;
FTXFMtdx = params.FT*XFMtdx;

if params.TVWeight
    DXFMtx = params.TV*(params.XFM'*x);
    DXFMtdx = params.TV*(params.XFM'*dx);
else
    DXFMtx = 0;
    DXFMtdx = 0;
end

if isfield(params,'TVt') && params.TVtWeight>0
    DTFMtx = params.TVt*(params.XFM'*x);
    DTFMtdx = params.TVt*(params.XFM'*dx);
else
    DTFMtx=0;
    DTFMtdx=0;
end


function [res, obj, RMS,TV,TVt,XFM,obj2] = objective(FTXFMtx, FTXFMtdx, DXFMtx, DXFMtdx,DTFMtx,DTFMtdx,XFMtx,XFMtdx,x,dx,t, params)
%calculated the objective function

p = params.pNorm;

obj = FTXFMtx + t*FTXFMtdx - params.data;
obj = obj(:)'*obj(:);

if params.TVWeight
    w = DXFMtx(:) + t*DXFMtdx(:);
    TV = (w.*conj(w)+params.l1Smooth).^(p/2); 
else
    TV = 0;
end

if isfield(params,'TVt') && params.TVtWeight>0 
    w = DTFMtx(:) + t*DTFMtdx(:);
    TVt = (w.*conj(w)+params.l1Smooth).^(p/2); 
    TVtWeight=params.TVtWeight;
else
    TVt=0;
    TVtWeight=0;
end
     
if params.xfmWeight
    if isfield(params,'masknz')
     masknz = params.masknz;
    else
     masknz=ones(size(x));
    end

   w = x(:) + t*dx(:); 
   XFM = masknz(:).*(w.*conj(w)+params.l1Smooth).^(p/2);
else
    XFM=0;
end


if isfield(params,'refWeight') && params.refWeight>0
 obj2=XFMtx+t*XFMtdx-params.ref;
 obj2=obj2(:)'*obj2(:)*params.refWeight;
else
    obj2=0;
end

TVt=sum(TVt.*TVtWeight);
TV = sum(TV)*params.TVWeight;
XFM = sum(XFM)*params.xfmWeight;
RMS = sqrt(obj/sum(abs(params.data(:))>0));

res = obj + (TV) + (XFM) +TVt+obj2;

function grad = wGradient(x,params)

gradXFM = 0;
gradTV = 0;
gradTVt=0;
gradObj2=0;

TVtWeight=0;
refWeight=0;
gradObj = gOBJ(x,params);

if params.xfmWeight
gradXFM = gXFM(x,params);
end
if params.TVWeight
gradTV = gTV(x,params);
end

if isfield(params,'TVtWeight') && params.TVtWeight>0
    gradTVt=gTVt(x,params);
    TVtWeight=params.TVtWeight;
end

if isfield(params,'refWeight') && params.refWeight>0
 gradObj2=gOBJ2(x,params);
 refWeight=params.refWeight;
end

grad = (gradObj +  params.xfmWeight.*gradXFM + params.TVWeight.*gradTV)+TVtWeight*gradTVt+refWeight*gradObj2;


function gradObj = gOBJ(x,params)
% computes the gradient of the data consistency

	gradObj = params.XFM*(params.FT'*(params.FT*(params.XFM'*x) - params.data));

gradObj = 2*gradObj ;

function gradObj = gOBJ2(x,params)
p=params.pNorm2;

alpha=params.alpha;
obj = (x - alpha*(params.XFM*params.ref));

gradObj = p*obj.*(obj.*conj(obj)+params.l1Smooth).^(p/2-1) ;


function grad = gXFM(x,params)
% compute gradient of the L1 transform operator

p = params.pNorm;
if isfield(params,'masknz')
  masknz = params.masknz;
else
    masknz=ones(size(x));
end

grad = p*x.*masknz.*(x.*conj(x)+params.l1Smooth).^(p/2-1);


function grad = gTV(x,params)
% compute gradient of TV operator

p = params.pNorm;

Dx = params.TV*(params.XFM'*x);

G = p*Dx.*(Dx.*conj(Dx) + params.l1Smooth).^(p/2-1);
grad = params.XFM*(params.TV'*G);

function grad = gTVt(x,params)
% compute gradient of TV operator along time

p = params.pNorm;

Dx = params.TVt*(params.XFM'*x);

G = p*Dx.*(Dx.*conj(Dx) + params.l1Smooth).^(p/2-1);
grad = params.XFM*(params.TVt'*G);





