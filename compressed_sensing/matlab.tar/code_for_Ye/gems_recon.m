function gems_recon(fid_prefix)
% tbgemsShaper(fid_dir,format)
% first dim: ro; second dim: pe; third dim: slice;
% 1/22/2011: Wrote it. Tested for single-slice 2D data. XZ
% format: output format: 'a': afni format. 's': sdt format.
np=readPar(fid_prefix,'np');
nv=readPar(fid_prefix,'nv');
ns=readPar(fid_prefix,'ns');

pro=readPar(fid_prefix,'pro');
ppe=readPar(fid_prefix,'ppe');
lro=readPar(fid_prefix,'lro');
lpe=readPar(fid_prefix,'lpe');
%figure;imagesc(m2);drawnow;
arraydim=readPar(fid_prefix,'arraydim');
ne=arraydim;

z=read_fid([fid_prefix,'.fid']);

z=reshape(z,[np/2,ns,nv,ne]);


%pelist=readPar(fid_prefix,'pelist');


z=permute(z,[1,3,2,4]);
z=fov_shift_kspace(z,[0,-ppe],[lro,lpe]);
b=ifft2c(z);


writesdt4(abs(b),[fid_prefix,'_mag']);
writesdt4(angle(b),[fid_prefix,'_ph']);


%%

